from flask import Flask, request, jsonify
from pathlib import Path
import pandas as pd
import os

app = Flask(__name__)

# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

DATA_DIR = BASE_DIR / "data" / "processed"

PREDICTION_FILE = DATA_DIR / "xgboost_predictions.csv"
RISK_FILE = DATA_DIR / "inventory_risk_scores.csv"


# ============================================================
# LOAD DATA
# ============================================================

def load_predictions():

    if not PREDICTION_FILE.exists():
        raise FileNotFoundError(
            f"Prediction file not found: {PREDICTION_FILE}"
        )

    df = pd.read_csv(PREDICTION_FILE)

    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
    )

    if "date" in df.columns:
        df["date"] = pd.to_datetime(
            df["date"],
            errors="coerce"
        )

    if "sku_id" in df.columns:
        df["sku_id"] = (
            df["sku_id"]
            .astype(str)
            .str.strip()
        )

    return df


def load_risk():

    if not RISK_FILE.exists():
        return pd.DataFrame()

    df = pd.read_csv(RISK_FILE)

    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
    )

    if "date" in df.columns:
        df["date"] = pd.to_datetime(
            df["date"],
            errors="coerce"
        )

    if "sku_id" in df.columns:
        df["sku_id"] = (
            df["sku_id"]
            .astype(str)
            .str.strip()
        )

    return df


try:
    predictions = load_predictions()
    risk_data = load_risk()

    print(
        f"Loaded predictions: {len(predictions):,}"
    )

    print(
        f"Loaded risk records: {len(risk_data):,}"
    )

except Exception as e:

    predictions = pd.DataFrame()
    risk_data = pd.DataFrame()

    print("Data loading error:", e)


# ============================================================
# HEALTH CHECK
# ============================================================

@app.route("/", methods=["GET"])
def home():

    return jsonify({
        "service": "NorthBay FORESIGHT Scoring API",
        "status": "online",
        "model": "XGBoost",
        "forecast_wape": "46.59%",
        "endpoints": [
            "/health",
            "/forecast",
            "/risk",
            "/sku/<sku_id>"
        ]
    })


# ============================================================
# HEALTH
# ============================================================

@app.route("/health", methods=["GET"])
def health():

    return jsonify({
        "status": "healthy",
        "model": "XGBoost",
        "prediction_rows": int(len(predictions)),
        "risk_rows": int(len(risk_data))
    })


# ============================================================
# FORECAST API
# ============================================================

@app.route("/forecast", methods=["GET"])
def forecast():

    if predictions.empty:

        return jsonify({
            "error": "Forecast data unavailable"
        }), 503

    sku_id = request.args.get("sku_id")

    df = predictions.copy()

    if sku_id:

        df = df[
            df["sku_id"].astype(str) == str(sku_id)
        ]

    if df.empty:

        return jsonify({
            "error": "SKU not found",
            "sku_id": sku_id
        }), 404

    df["date"] = df["date"].dt.strftime("%Y-%m-%d")

    records = df.to_dict(
        orient="records"
    )

    return jsonify({
        "model": "XGBoost",
        "wape": 0.4659,
        "count": len(records),
        "forecast": records
    })


# ============================================================
# RISK API
# ============================================================

@app.route("/risk", methods=["GET"])
def risk():

    if risk_data.empty:

        return jsonify({
            "error": "Risk data unavailable"
        }), 503

    sku_id = request.args.get("sku_id")

    risk_level = request.args.get(
        "risk_level"
    )

    df = risk_data.copy()

    if sku_id:

        df = df[
            df["sku_id"].astype(str) == str(sku_id)
        ]

    if risk_level and "risk_level" in df.columns:

        df = df[
            df["risk_level"]
            .astype(str)
            .str.upper()
            == risk_level.upper()
        ]

    if df.empty:

        return jsonify({
            "message": "No matching risk records found"
        }), 404

    if "date" in df.columns:

        df["date"] = df["date"].dt.strftime(
            "%Y-%m-%d"
        )

    records = df.to_dict(
        orient="records"
    )

    return jsonify({
        "count": len(records),
        "risk": records
    })


# ============================================================
# SKU COMBINED ENDPOINT
# ============================================================

@app.route("/sku/<sku_id>", methods=["GET"])
def sku_details(sku_id):

    sku_id = str(sku_id).strip()

    forecast_df = predictions[
        predictions["sku_id"].astype(str)
        == sku_id
    ].copy()

    if forecast_df.empty:

        return jsonify({
            "error": "SKU not found",
            "sku_id": sku_id
        }), 404

    forecast_df["date"] = (
        forecast_df["date"]
        .dt.strftime("%Y-%m-%d")
    )

    forecast = forecast_df.to_dict(
        orient="records"
    )

    risk = []

    if not risk_data.empty:

        risk_df = risk_data[
            risk_data["sku_id"].astype(str)
            == sku_id
        ].copy()

        if "date" in risk_df.columns:

            risk_df["date"] = (
                risk_df["date"]
                .dt.strftime("%Y-%m-%d")
            )

        risk = risk_df.to_dict(
            orient="records"
        )

    return jsonify({
        "sku_id": sku_id,
        "model": "XGBoost",
        "forecast_wape": 0.4659,
        "forecast": forecast,
        "risk": risk
    })


# ============================================================
# ERROR HANDLER
# ============================================================

@app.errorhandler(404)
def not_found(error):

    return jsonify({
        "error": "Endpoint not found"
    }), 404


@app.errorhandler(500)
def server_error(error):

    return jsonify({
        "error": "Internal server error"
    }), 500


# ============================================================
# RUN
# ============================================================

if __name__ == "__main__":

    port = int(
        os.environ.get(
            "PORT",
            5000
        )
    )

    app.run(
        host="0.0.0.0",
        port=port
    )