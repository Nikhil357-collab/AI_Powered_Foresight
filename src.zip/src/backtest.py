from pathlib import Path

import numpy as np
import pandas as pd
from xgboost import XGBRegressor


BASE_DIR = Path(__file__).resolve().parents[1]

DATA_DIR = BASE_DIR / "data"
PROCESSED_DIR = DATA_DIR / "processed"

PROCESSED_DIR.mkdir(
    parents=True,
    exist_ok=True
)


def wape(actual, predicted):

    actual = np.asarray(actual)
    predicted = np.asarray(predicted)

    denominator = np.sum(np.abs(actual))

    if denominator == 0:
        return 0.0

    return (
        np.sum(np.abs(actual - predicted))
        / denominator
    )


def bias(actual, predicted):

    actual = np.asarray(actual)
    predicted = np.asarray(predicted)

    return np.mean(predicted - actual)


def prepare_data(df):

    df = df.copy()

    df["date"] = pd.to_datetime(
        df["date"]
    )

    df = df.sort_values(
        ["sku_id", "date"]
    ).reset_index(drop=True)

    return df


def create_features(df):

    df = df.copy()

    categorical_columns = [
        "store_id",
        "sku_id",
        "category",
        "subcategory",
        "brand",
        "month_name",
        "day_name",
        "season",
        "promo_event"
    ]

    for column in categorical_columns:

        if column in df.columns:

            df[column] = (
                df[column]
                .astype("category")
                .cat.codes
            )

    excluded_columns = [
        "date",
        "units_sold",
        "revenue",
        "last_restock_date"
    ]

    feature_columns = []

    for column in df.columns:

        if column in excluded_columns:
            continue

        if pd.api.types.is_numeric_dtype(
            df[column]
        ):
            feature_columns.append(column)

    return df, feature_columns


def seasonal_naive_forecast(
    train,
    test,
    seasonal_period=7
):

    history = (
        train
        .sort_values(
            ["sku_id", "date"]
        )
        .copy()
    )

    predictions = []

    last_values = {}

    for sku_id, group in history.groupby(
        "sku_id"
    ):

        values = group[
            "units_sold"
        ].values

        if len(values) >= seasonal_period:
            last_values[sku_id] = (
                values[-seasonal_period:]
            )
        else:
            last_values[sku_id] = values

    for _, row in test.iterrows():

        sku_id = row["sku_id"]

        values = last_values.get(
            sku_id,
            np.array([0.0])
        )

        if len(values) >= seasonal_period:

            prediction = values[
                -seasonal_period
            ]

        else:

            prediction = values[-1]

        predictions.append(
            max(float(prediction), 0.0)
        )

    return np.array(predictions)


def train_xgboost(
    train,
    feature_columns
):

    X_train = train[
        feature_columns
    ]

    y_train = train[
        "units_sold"
    ]

    model = XGBRegressor(
        objective="reg:squarederror",
        n_estimators=500,
        learning_rate=0.05,
        max_depth=8,
        min_child_weight=5,
        subsample=0.8,
        colsample_bytree=0.8,
        reg_alpha=0.1,
        reg_lambda=1.0,
        random_state=42,
        n_jobs=-1
    )

    model.fit(
        X_train,
        y_train
    )

    return model


def run_fold(
    df,
    feature_columns,
    train_end,
    test_start,
    test_end,
    fold_number
):

    print("\n" + "=" * 70)
    print(f"FOLD {fold_number}")
    print("=" * 70)

    train = df[
        df["date"] <= train_end
    ].copy()

    test = df[
        (df["date"] >= test_start) &
        (df["date"] <= test_end)
    ].copy()

    print(
        f"Train: "
        f"{train['date'].min().date()} "
        f"to "
        f"{train['date'].max().date()}"
    )

    print(
        f"Test : "
        f"{test['date'].min().date()} "
        f"to "
        f"{test['date'].max().date()}"
    )

    print(
        f"Train rows: "
        f"{len(train):,}"
    )

    print(
        f"Test rows : "
        f"{len(test):,}"
    )

    actual = test[
        "units_sold"
    ].values

    print(
        "\nCreating Seasonal Naive "
        "predictions..."
    )

    baseline_predictions = (
        seasonal_naive_forecast(
            train,
            test,
            seasonal_period=7
        )
    )

    baseline_wape = wape(
        actual,
        baseline_predictions
    )

    baseline_bias = bias(
        actual,
        baseline_predictions
    )

    print(
        f"Baseline WAPE : "
        f"{baseline_wape:.4f}"
    )

    print(
        f"Baseline Bias : "
        f"{baseline_bias:.4f}"
    )

    print(
        "\nTraining XGBoost..."
    )

    model = train_xgboost(
        train,
        feature_columns
    )

    ml_predictions = model.predict(
        test[feature_columns]
    )

    ml_predictions = np.maximum(
        ml_predictions,
        0
    )

    ml_wape = wape(
        actual,
        ml_predictions
    )

    ml_bias = bias(
        actual,
        ml_predictions
    )

    print(
        f"ML WAPE       : "
        f"{ml_wape:.4f}"
    )

    print(
        f"ML Bias       : "
        f"{ml_bias:.4f}"
    )

    improvement = (
        (baseline_wape - ml_wape)
        / baseline_wape
        if baseline_wape != 0
        else 0
    )

    if ml_wape < baseline_wape:
        result = "ML BETTER"
    else:
        result = "BASELINE BETTER"

    print(
        f"Improvement   : "
        f"{improvement:.2%}"
    )

    print(
        f"Result        : "
        f"{result}"
    )

    return {
        "fold": fold_number,
        "train_end": train_end,
        "test_start": test_start,
        "test_end": test_end,
        "train_rows": len(train),
        "test_rows": len(test),
        "baseline_wape": baseline_wape,
        "ml_wape": ml_wape,
        "baseline_bias": baseline_bias,
        "ml_bias": ml_bias,
        "improvement": improvement
    }


def main():

    print("=" * 70)
    print("NORTHBAY FORESIGHT")
    print("FINAL DAY 13-14 ROLLING-ORIGIN BACKTEST")
    print("=" * 70)

    feature_path = (
        PROCESSED_DIR /
        "model_features.csv"
    )

    print(
        "\nLoading feature dataset..."
    )

    df = pd.read_csv(
        feature_path
    )

    df = prepare_data(df)

    print(
        f"Rows: "
        f"{len(df):,}"
    )

    print(
        f"Date range: "
        f"{df['date'].min().date()} "
        f"to "
        f"{df['date'].max().date()}"
    )

    df, feature_columns = (
        create_features(df)
    )

    print(
        f"Model features: "
        f"{len(feature_columns)}"
    )

    folds = [

        (
            pd.Timestamp("2025-09-02"),
            pd.Timestamp("2025-09-03"),
            pd.Timestamp("2025-10-02")
        ),

        (
            pd.Timestamp("2025-10-02"),
            pd.Timestamp("2025-10-03"),
            pd.Timestamp("2025-11-01")
        ),

        (
            pd.Timestamp("2025-11-01"),
            pd.Timestamp("2025-11-02"),
            pd.Timestamp("2025-12-01")
        ),

        (
            pd.Timestamp("2025-12-01"),
            pd.Timestamp("2025-12-02"),
            pd.Timestamp("2025-12-31")
        )
    ]

    results = []

    for fold_number, (
        train_end,
        test_start,
        test_end
    ) in enumerate(
        folds,
        start=1
    ):

        result = run_fold(
            df,
            feature_columns,
            train_end,
            test_start,
            test_end,
            fold_number
        )

        results.append(
            result
        )

    results_df = pd.DataFrame(
        results
    )

    average_baseline = (
        results_df[
            "baseline_wape"
        ].mean()
    )

    average_ml = (
        results_df[
            "ml_wape"
        ].mean()
    )

    average_improvement = (
        (average_baseline - average_ml)
        / average_baseline
        if average_baseline != 0
        else 0
    )

    average_ml_bias = (
        results_df[
            "ml_bias"
        ].mean()
    )

    print("\n" + "=" * 70)
    print("FINAL ROLLING-ORIGIN RESULTS")
    print("=" * 70)

    display_columns = [
        "fold",
        "test_start",
        "test_end",
        "baseline_wape",
        "ml_wape",
        "improvement",
        "ml_bias"
    ]

    print(
        results_df[
            display_columns
        ].to_string(
            index=False
        )
    )

    print("\n" + "=" * 70)
    print("MODEL SELECTION SUMMARY")
    print("=" * 70)

    print(
        f"\nAverage Seasonal Naive WAPE : "
        f"{average_baseline:.4f}"
    )

    print(
        f"Average XGBoost WAPE        : "
        f"{average_ml:.4f}"
    )

    print(
        f"Average relative improvement: "
        f"{average_improvement:.2%}"
    )

    print(
        f"Average XGBoost Bias        : "
        f"{average_ml_bias:.4f}"
    )

    if average_ml < average_baseline:

        print(
            "\nFINAL DECISION: "
            "SELECT XGBOOST MODEL"
        )

    else:

        print(
            "\nFINAL DECISION: "
            "KEEP SEASONAL NAIVE BASELINE"
        )

    output_path = (
        PROCESSED_DIR /
        "final_backtest_results.csv"
    )

    results_df.to_csv(
        output_path,
        index=False
    )

    print(
        f"\n✓ Results saved:"
        f"\n{output_path}"
    )

    print("\nBacktesting completed.")


if __name__ == "__main__":
    main()