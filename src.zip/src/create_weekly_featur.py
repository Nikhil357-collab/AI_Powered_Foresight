from pathlib import Path
import pandas as pd
import numpy as np


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parents[1]

PROCESSED_DIR = BASE_DIR / "data" / "processed"

OUTPUT_FILE = PROCESSED_DIR / "weekly_model_features.csv"


# ============================================================
# LOAD DATA
# ============================================================

def load_data():

    print("=" * 70)
    print("NORTHBAY FORESIGHT")
    print("WEEKLY FORECAST FEATURE ENGINEERING")
    print("=" * 70)

    sales = pd.read_csv(
        PROCESSED_DIR / "sales_daily_clean.csv"
    )

    sku = pd.read_csv(
        PROCESSED_DIR / "sku_master_clean.csv"
    )

    calendar = pd.read_csv(
        PROCESSED_DIR / "calendar_clean.csv"
    )

    print(f"Sales rows : {len(sales):,}")

    return sales, sku, calendar


# ============================================================
# PREPARE SALES
# ============================================================

def prepare_sales(sales):

    sales = sales.copy()

    sales["date"] = pd.to_datetime(
        sales["date"],
        errors="coerce"
    )

    sales["units_sold"] = pd.to_numeric(
        sales["units_sold"],
        errors="coerce"
    ).fillna(0)

    sales = sales.dropna(
        subset=["date", "sku_id"]
    )

    return sales


# ============================================================
# WEEKLY AGGREGATION
# ============================================================

def create_weekly_sales(sales):

    print("\nCreating weekly SKU demand...")

    # Monday-starting weeks
    sales["week_start"] = (
        sales["date"]
        - pd.to_timedelta(
            sales["date"].dt.dayofweek,
            unit="D"
        )
    )

    group_cols = [
        "sku_id",
        "week_start"
    ]

    if "store_id" in sales.columns:

        group_cols = [
            "store_id",
            "sku_id",
            "week_start"
        ]

    weekly = (
        sales
        .groupby(group_cols, as_index=False)
        ["units_sold"]
        .sum()
    )

    weekly = weekly.rename(
        columns={
            "units_sold": "weekly_demand"
        }
    )

    print(
        f"Weekly rows: {len(weekly):,}"
    )

    return weekly


# ============================================================
# COMPLETE TIME SERIES
# ============================================================

def complete_weekly_series(df):

    print("\nCreating complete weekly time series...")

    result = []

    grouping = ["sku_id"]

    if "store_id" in df.columns:
        grouping = ["store_id", "sku_id"]

    for keys, group in df.groupby(grouping):

        group = group.sort_values("week_start")

        start = group["week_start"].min()
        end = group["week_start"].max()

        dates = pd.date_range(
            start=start,
            end=end,
            freq="7D"
        )

        if isinstance(keys, tuple):
            values = dict(
                zip(grouping, keys)
            )
        else:
            values = {
                grouping[0]: keys
            }

        temp = pd.DataFrame(
            {
                "week_start": dates
            }
        )

        for col, value in values.items():
            temp[col] = value

        temp = temp.merge(
            group,
            on=grouping + ["week_start"],
            how="left"
        )

        temp["weekly_demand"] = (
            temp["weekly_demand"]
            .fillna(0)
        )

        result.append(temp)

    df = pd.concat(
        result,
        ignore_index=True
    )

    print(
        f"Complete weekly rows: {len(df):,}"
    )

    return df


# ============================================================
# TIME FEATURES
# ============================================================

def create_time_features(df):

    print("\nCreating time features...")

    df = df.copy()

    df["year"] = (
        df["week_start"].dt.year
    )

    df["month"] = (
        df["week_start"].dt.month
    )

    df["quarter"] = (
        df["week_start"].dt.quarter
    )

    df["week_of_year"] = (
        df["week_start"]
        .dt.isocalendar()
        .week
        .astype(int)
    )

    # Cyclic encoding
    df["week_sin"] = np.sin(
        2 * np.pi *
        df["week_of_year"] / 52
    )

    df["week_cos"] = np.cos(
        2 * np.pi *
        df["week_of_year"] / 52
    )

    return df


# ============================================================
# LAG FEATURES
# ============================================================

def create_lag_features(df):

    print("\nCreating leakage-safe lag features...")

    df = df.sort_values(
        ["sku_id", "week_start"]
    )

    group_cols = ["sku_id"]

    if "store_id" in df.columns:
        group_cols = [
            "store_id",
            "sku_id"
        ]

    grouped = df.groupby(
        group_cols
    )["weekly_demand"]

    lag_periods = [
        1,
        2,
        3,
        4,
        8,
        12,
        13,
        26,
        52
    ]

    for lag in lag_periods:

        df[f"lag_{lag}w"] = (
            grouped.shift(lag)
        )

    return df


# ============================================================
# ROLLING FEATURES
# ============================================================

def create_rolling_features(df):

    print("\nCreating rolling demand features...")

    df = df.sort_values(
        ["sku_id", "week_start"]
    )

    group_cols = ["sku_id"]

    if "store_id" in df.columns:
        group_cols = [
            "store_id",
            "sku_id"
        ]

    grouped = df.groupby(
        group_cols
    )["weekly_demand"]

    # IMPORTANT:
    # Shift BEFORE rolling.
    # This prevents current/future demand
    # entering the feature.

    for window in [4, 8, 12, 26]:

        df[f"rolling_mean_{window}w"] = (
            grouped
            .shift(1)
            .rolling(window)
            .mean()
            .reset_index(
                level=group_cols,
                drop=True
            )
        )

        df[f"rolling_std_{window}w"] = (
            grouped
            .shift(1)
            .rolling(window)
            .std()
            .reset_index(
                level=group_cols,
                drop=True
            )
        )

    return df


# ============================================================
# TREND FEATURES
# ============================================================

def create_trend_features(df):

    print("\nCreating demand trend features...")

    df["demand_change_4w"] = (
        df["lag_1w"] -
        df["lag_4w"]
    )

    df["demand_change_12w"] = (
        df["lag_1w"] -
        df["lag_12w"]
    )

    df["demand_growth_4w"] = (
        df["lag_1w"] /
        (df["lag_4w"] + 1)
    )

    df["demand_growth_12w"] = (
        df["lag_1w"] /
        (df["lag_12w"] + 1)
    )

    return df


# ============================================================
# SKU FEATURES
# ============================================================

def merge_sku_features(
    df,
    sku
):

    print("\nMerging SKU information...")

    columns = [
        "sku_id",
        "category",
        "subcategory",
        "brand",
        "unit_price",
        "cost_price"
    ]

    available = [
        c for c in columns
        if c in sku.columns
    ]

    sku_small = (
        sku[available]
        .drop_duplicates("sku_id")
    )

    df = df.merge(
        sku_small,
        on="sku_id",
        how="left"
    )

    if {
        "unit_price",
        "cost_price"
    }.issubset(df.columns):

        df["unit_margin"] = (
            df["unit_price"] -
            df["cost_price"]
        )

        df["margin_pct"] = (
            df["unit_margin"] /
            (df["unit_price"] + 1e-6)
        )

    return df


# ============================================================
# CALENDAR FEATURES
# ============================================================

def merge_calendar_features(
    df,
    calendar
):

    print("\nMerging calendar features...")

    calendar = calendar.copy()

    calendar["date"] = pd.to_datetime(
        calendar["date"],
        errors="coerce"
    )

    calendar["week_start"] = (
        calendar["date"]
        - pd.to_timedelta(
            calendar["date"].dt.dayofweek,
            unit="D"
        )
    )

    calendar = calendar.drop_duplicates(
        "week_start"
    )

    # Keep only non-date columns
    calendar_cols = [
        c for c in calendar.columns
        if c not in ["date"]
    ]

    df = df.merge(
        calendar[calendar_cols],
        on="week_start",
        how="left",
        suffixes=("", "_calendar")
    )

    return df


# ============================================================
# MISSING VALUES
# ============================================================

def handle_missing_values(df):

    print("\nHandling missing values...")

    numeric_cols = df.select_dtypes(
        include=np.number
    ).columns

    # For demand history:
    # missing historical observations mean insufficient history.
    # We fill them conservatively only after creating features.

    for col in numeric_cols:

        df[col] = df[col].replace(
            [np.inf, -np.inf],
            np.nan
        )

        if col != "weekly_demand":

            df[col] = (
                df[col]
                .fillna(0)
            )

    return df


# ============================================================
# SAVE
# ============================================================

def save_features(df):

    df.to_csv(
        OUTPUT_FILE,
        index=False
    )

    print("\n" + "=" * 70)
    print("WEEKLY FEATURE DATASET CREATED")
    print("=" * 70)

    print(
        f"File    : {OUTPUT_FILE}"
    )

    print(
        f"Rows    : {len(df):,}"
    )

    print(
        f"Columns : {len(df.columns):,}"
    )


# ============================================================
# MAIN
# ============================================================

def main():

    sales, sku, calendar = load_data()

    sales = prepare_sales(
        sales
    )

    weekly = create_weekly_sales(
        sales
    )

    weekly = complete_weekly_series(
        weekly
    )

    weekly = create_time_features(
        weekly
    )

    weekly = create_lag_features(
        weekly
    )

    weekly = create_rolling_features(
        weekly
    )

    weekly = create_trend_features(
        weekly
    )

    weekly = merge_sku_features(
        weekly,
        sku
    )

    weekly = merge_calendar_features(
        weekly,
        calendar
    )

    weekly = handle_missing_values(
        weekly
    )

    save_features(
        weekly
    )


if __name__ == "__main__":
    main()