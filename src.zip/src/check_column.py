from pathlib import Path
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"


files = [
    "sales_daily.csv",
    "sku_master.csv",
    "inventory_snapshots.csv",
    "promotions.csv",
    "calendar.csv",
    "model_features.csv"]


for file_name in files:

    file_path = DATA_DIR / file_name

    print("\n" + "=" * 80)
    print(f"FILE: {file_name}")
    print("=" * 80)

    if not file_path.exists():
        print("❌ FILE NOT FOUND")
        continue

    df = pd.read_csv(file_path, nrows=5)

    print("\nActual columns:")
    
    for i, column in enumerate(df.columns, 1):
        print(f"{i:02d}. [{column}]")

    print("\nShape of first 5 rows:")
    print(df.shape)

    print("\nSample:")
    print(df.head())