from pathlib import Path

import pandas as pd
import numpy as np


# ============================================================
# NORTHBAY FORESIGHT
# DATA CLEANING PIPELINE
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

DATA_DIR = PROJECT_ROOT / "data"
PROCESSED_DIR = DATA_DIR / "processed"

PROCESSED_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# EXPECTED SCHEMAS
# ============================================================

SALES_COLUMNS = [
    "date",
    "sku_id",
    "units_sold",
    "revenue",
    "avg_unit_price",
    "transaction_count",
    "promo_flag",
]

SKU_COLUMNS = [
    "sku_id",
    "sku_name",
    "category",
    "subcategory",
    "unit_price",
    "cost_price",
    "brand",
]

INVENTORY_COLUMNS = [
    "store_id",
    "sku_id",
    "stock_on_hand",
    "reorder_point",
    "safety_stock",
    "last_restock_date",
]

PROMOTION_COLUMNS = [
    "promo_id",
    "promo_name",
    "start_date",
    "end_date",
    "discount_pct",
    "promo_type",
    "target_type",
    "target_value",
]

CALENDAR_COLUMNS = [
    "date",
]


# ============================================================
# GENERAL HELPERS
# ============================================================

def clean_column_names(df):
    """
    Standardize dataframe column names.

    Example:
        'Unit Price' -> 'unit_price'
        'SKU-ID'     -> 'sku_id'
    """

    df = df.copy()

    df.columns = (
        df.columns
        .astype(str)
        .str.strip()
        .str.lower()
        .str.replace(" ", "_", regex=False)
        .str.replace("-", "_", regex=False)
        .str.replace("/", "_", regex=False)
    )

    return df


# ============================================================
# SCHEMA VALIDATION
# ============================================================

def validate_required_columns(
    df,
    required_columns,
    dataset_name
):
    """
    Validate required columns.

    Returns:
        True  -> schema valid
        False -> schema invalid
    """

    missing = [
        column
        for column in required_columns
        if column not in df.columns
    ]

    additional = [
        column
        for column in df.columns
        if column not in required_columns
    ]

    print("\n" + "-" * 70)
    print(f"SCHEMA VALIDATION: {dataset_name}")
    print("-" * 70)

    if missing:

        print("❌ Missing required columns:")

        for column in missing:
            print(f"   - {column}")

        print("\nActual columns:")

        for column in df.columns:
            print(f"   - {column}")

        return False

    print("✓ All required columns present")

    if additional:

        print("\n⚠ Additional columns found:")

        for column in additional:
            print(f"   + {column}")

        print(
            "\nThese columns are allowed and will be retained."
        )

    else:

        print("✓ No additional columns")

    return True


# ============================================================
# QUALITY REPORT
# ============================================================

def print_quality_report(df, dataset_name):
    """
    Print data quality statistics.
    """

    print("\n" + "=" * 70)
    print(f"QUALITY REPORT: {dataset_name}")
    print("=" * 70)

    print(f"Rows              : {len(df):,}")
    print(f"Columns           : {len(df.columns):,}")

    print(
        f"Duplicate rows    : "
        f"{df.duplicated().sum():,}"
    )

    print(
        f"Missing cells     : "
        f"{df.isna().sum().sum():,}"
    )

    print("\nMissing values by column:")

    missing = df.isna().sum()

    any_missing = False

    for column, count in missing.items():

        if count > 0:

            any_missing = True

            percentage = (
                count / len(df) * 100
                if len(df) > 0
                else 0
            )

            print(
                f"⚠ {column}: "
                f"{count:,} "
                f"({percentage:.2f}%)"
            )

    if not any_missing:

        print("✓ No missing values")


# ============================================================
# SALES CLEANING
# ============================================================

def clean_sales(df):

    print("\nCleaning sales_daily...")

    df = df.copy()

    # --------------------------------------------------------
    # Column names
    # --------------------------------------------------------

    df = clean_column_names(df)

    # --------------------------------------------------------
    # Schema validation
    # --------------------------------------------------------

    valid = validate_required_columns(
        df,
        SALES_COLUMNS,
        "sales_daily"
    )

    if not valid:

        raise ValueError(
            "sales_daily schema validation failed."
        )

    # --------------------------------------------------------
    # Date
    # --------------------------------------------------------

    df["date"] = pd.to_datetime(
        df["date"],
        errors="coerce"
    )

    invalid_dates = df["date"].isna().sum()

    if invalid_dates > 0:

        print(
            f"⚠ Removing {invalid_dates:,} "
            "rows with invalid dates."
        )

        df = df.dropna(
            subset=["date"]
        )

    else:

        print("✓ Date validation passed")

    # --------------------------------------------------------
    # SKU
    # --------------------------------------------------------

    df["sku_id"] = (
        df["sku_id"]
        .astype("string")
        .str.strip()
    )

    invalid_sku = (
        df["sku_id"].isna()
        | (df["sku_id"] == "")
    )

    invalid_sku_count = invalid_sku.sum()

    if invalid_sku_count > 0:

        print(
            f"⚠ Removing {invalid_sku_count:,} "
            "rows with missing SKU."
        )

        df = df.loc[~invalid_sku].copy()

    else:

        print("✓ SKU validation passed")

    # --------------------------------------------------------
    # Numeric columns
    # --------------------------------------------------------

    numeric_columns = [
        "units_sold",
        "revenue",
        "avg_unit_price",
        "transaction_count",
        "promo_flag",
    ]

    for column in numeric_columns:

        df[column] = pd.to_numeric(
            df[column],
            errors="coerce"
        )

    print("✓ Numeric conversion completed")

    # --------------------------------------------------------
    # Missing numeric values
    # --------------------------------------------------------

    for column in numeric_columns:

        missing_count = df[column].isna().sum()

        if missing_count > 0:

            print(
                f"⚠ {column}: "
                f"{missing_count:,} missing values"
            )

    # --------------------------------------------------------
    # Business-rule validation
    # --------------------------------------------------------

    # Units sold cannot be negative
    negative_units = (
        df["units_sold"] < 0
    ).sum()

    if negative_units > 0:

        print(
            f"⚠ Setting {negative_units:,} "
            "negative units_sold values to NaN."
        )

        df.loc[
            df["units_sold"] < 0,
            "units_sold"
        ] = np.nan

    # Revenue cannot be negative
    negative_revenue = (
        df["revenue"] < 0
    ).sum()

    if negative_revenue > 0:

        print(
            f"⚠ Setting {negative_revenue:,} "
            "negative revenue values to NaN."
        )

        df.loc[
            df["revenue"] < 0,
            "revenue"
        ] = np.nan

    # Price cannot be negative
    negative_price = (
        df["avg_unit_price"] < 0
    ).sum()

    if negative_price > 0:

        print(
            f"⚠ Setting {negative_price:,} "
            "negative avg_unit_price values to NaN."
        )

        df.loc[
            df["avg_unit_price"] < 0,
            "avg_unit_price"
        ] = np.nan

    # Transaction count cannot be negative
    negative_transactions = (
        df["transaction_count"] < 0
    ).sum()

    if negative_transactions > 0:

        print(
            f"⚠ Setting {negative_transactions:,} "
            "negative transaction counts to NaN."
        )

        df.loc[
            df["transaction_count"] < 0,
            "transaction_count"
        ] = np.nan

    # Promo flag should be 0/1
    invalid_promo = ~df["promo_flag"].isin(
        [0, 1]
    )

    invalid_promo_count = invalid_promo.sum()

    if invalid_promo_count > 0:

        print(
            f"⚠ Found {invalid_promo_count:,} "
            "invalid promo_flag values."
        )

        df.loc[
            invalid_promo,
            "promo_flag"
        ] = np.nan

    # --------------------------------------------------------
    # Remove duplicate SKU-date records
    # --------------------------------------------------------

    duplicate_keys = df.duplicated(
        subset=["date", "sku_id"]
    ).sum()

    if duplicate_keys > 0:

        print(
            f"⚠ Removing {duplicate_keys:,} "
            "duplicate date-SKU records."
        )

        df = df.drop_duplicates(
            subset=["date", "sku_id"],
            keep="last"
        )

    else:

        print(
            "✓ No duplicate date-SKU records"
        )

    # --------------------------------------------------------
    # Sort
    # --------------------------------------------------------

    df = (
        df.sort_values(
            ["sku_id", "date"]
        )
        .reset_index(drop=True)
    )

    print("✓ Sales sorting completed")

    # --------------------------------------------------------
    # Final validation
    # --------------------------------------------------------

    final_valid = validate_required_columns(
        df,
        SALES_COLUMNS,
        "sales_daily - final"
    )

    if not final_valid:

        raise ValueError(
            "sales_daily failed final validation."
        )

    print_quality_report(
        df,
        "sales_daily - cleaned"
    )

    # IMPORTANT:
    # Return DataFrame
    return df


# ============================================================
# SKU MASTER CLEANING
# ============================================================

def clean_sku_master(df):

    print("\nCleaning sku_master...")

    df = df.copy()

    df = clean_column_names(df)

    valid = validate_required_columns(
        df,
        SKU_COLUMNS,
        "sku_master"
    )

    if not valid:

        raise ValueError(
            "sku_master schema validation failed."
        )

    # --------------------------------------------------------
    # SKU ID
    # --------------------------------------------------------

    df["sku_id"] = (
        df["sku_id"]
        .astype("string")
        .str.strip()
    )

    # --------------------------------------------------------
    # Text columns
    # --------------------------------------------------------

    text_columns = [
        "sku_name",
        "category",
        "subcategory",
        "brand",
    ]

    for column in text_columns:

        df[column] = (
            df[column]
            .astype("string")
            .str.strip()
        )

    # --------------------------------------------------------
    # Numeric
    # --------------------------------------------------------

    for column in [
        "unit_price",
        "cost_price",
    ]:

        df[column] = pd.to_numeric(
            df[column],
            errors="coerce"
        )

    # --------------------------------------------------------
    # Negative financial values
    # --------------------------------------------------------

    for column in [
        "unit_price",
        "cost_price",
    ]:

        negative_count = (
            df[column] < 0
        ).sum()

        if negative_count > 0:

            print(
                f"⚠ {column}: "
                f"{negative_count:,} negative values."
            )

            df.loc[
                df[column] < 0,
                column
            ] = np.nan

    # --------------------------------------------------------
    # Remove duplicate SKUs
    # --------------------------------------------------------

    duplicate_skus = (
        df["sku_id"].duplicated().sum()
    )

    if duplicate_skus > 0:

        print(
            f"⚠ Removing {duplicate_skus:,} "
            "duplicate SKU records."
        )

        df = df.drop_duplicates(
            subset=["sku_id"],
            keep="last"
        )

    else:

        print("✓ SKU IDs are unique")

    df = df.reset_index(drop=True)

    print_quality_report(
        df,
        "sku_master - cleaned"
    )

    return df


# ============================================================
# INVENTORY CLEANING
# ============================================================

def clean_inventory(df):

    print("\nCleaning inventory_snapshots...")

    df = df.copy()

    df = clean_column_names(df)

    valid = validate_required_columns(
        df,
        INVENTORY_COLUMNS,
        "inventory_snapshots"
    )

    if not valid:

        raise ValueError(
            "inventory_snapshots schema validation failed."
        )

    # --------------------------------------------------------
    # IDs
    # --------------------------------------------------------

    df["sku_id"] = (
        df["sku_id"]
        .astype("string")
        .str.strip()
    )

    df["store_id"] = (
        df["store_id"]
        .astype("string")
        .str.strip()
    )

    # --------------------------------------------------------
    # Numeric
    # --------------------------------------------------------

    numeric_columns = [
        "stock_on_hand",
        "reorder_point",
        "safety_stock",
    ]

    for column in numeric_columns:

        df[column] = pd.to_numeric(
            df[column],
            errors="coerce"
        )

    # --------------------------------------------------------
    # Restock date
    # --------------------------------------------------------

    df["last_restock_date"] = pd.to_datetime(
        df["last_restock_date"],
        errors="coerce"
    )

    # --------------------------------------------------------
    # Negative inventory values
    # --------------------------------------------------------

    for column in numeric_columns:

        negative_count = (
            df[column] < 0
        ).sum()

        if negative_count > 0:

            print(
                f"⚠ {column}: "
                f"{negative_count:,} "
                "negative values."
            )

            df.loc[
                df[column] < 0,
                column
            ] = np.nan

    # --------------------------------------------------------
    # Remove duplicates
    # --------------------------------------------------------

    duplicate_count = df.duplicated().sum()

    if duplicate_count > 0:

        print(
            f"⚠ Removing {duplicate_count:,} "
            "exact duplicate rows."
        )

        df = df.drop_duplicates()

    else:

        print("✓ No exact duplicate inventory rows")

    df = df.reset_index(drop=True)

    print_quality_report(
        df,
        "inventory_snapshots - cleaned"
    )

    return df


# ============================================================
# PROMOTION CLEANING
# ============================================================

def clean_promotions(df):

    print("\nCleaning promotions...")

    df = df.copy()

    df = clean_column_names(df)

    valid = validate_required_columns(
        df,
        PROMOTION_COLUMNS,
        "promotions"
    )

    if not valid:

        raise ValueError(
            "promotions schema validation failed."
        )

    # --------------------------------------------------------
    # Promotion ID
    # --------------------------------------------------------

    df["promo_id"] = (
        df["promo_id"]
        .astype("string")
        .str.strip()
    )

    # --------------------------------------------------------
    # Text columns
    # --------------------------------------------------------

    text_columns = [
        "promo_name",
        "promo_type",
        "target_type",
    ]

    for column in text_columns:

        df[column] = (
            df[column]
            .astype("string")
            .str.strip()
        )

    # --------------------------------------------------------
    # Dates
    # --------------------------------------------------------

    df["start_date"] = pd.to_datetime(
        df["start_date"],
        errors="coerce"
    )

    df["end_date"] = pd.to_datetime(
        df["end_date"],
        errors="coerce"
    )

    # --------------------------------------------------------
    # Discount
    # --------------------------------------------------------

    df["discount_pct"] = pd.to_numeric(
        df["discount_pct"],
        errors="coerce"
    )

    invalid_discount = (
        (df["discount_pct"] < 0)
        |
        (df["discount_pct"] > 100)
    )

    invalid_discount_count = (
        invalid_discount.sum()
    )

    if invalid_discount_count > 0:

        print(
            f"⚠ Found "
            f"{invalid_discount_count:,} "
            "invalid discount values."
        )

        df.loc[
            invalid_discount,
            "discount_pct"
        ] = np.nan

    # --------------------------------------------------------
    # Invalid date ranges
    # --------------------------------------------------------

    invalid_dates = (
        df["end_date"] < df["start_date"]
    )

    invalid_date_count = invalid_dates.sum()

    if invalid_date_count > 0:

        print(
            f"⚠ Found "
            f"{invalid_date_count:,} "
            "invalid promotion date ranges."
        )

        df.loc[
            invalid_dates,
            ["start_date", "end_date"]
        ] = pd.NaT

    # --------------------------------------------------------
    # Remove exact duplicates
    # --------------------------------------------------------

    duplicate_count = df.duplicated().sum()

    if duplicate_count > 0:

        print(
            f"⚠ Removing "
            f"{duplicate_count:,} "
            "duplicate promotion rows."
        )

        df = df.drop_duplicates()

    df = df.reset_index(drop=True)

    print_quality_report(
        df,
        "promotions - cleaned"
    )

    return df


# ============================================================
# CALENDAR CLEANING
# ============================================================

def clean_calendar(df):

    print("\nCleaning calendar...")

    df = df.copy()

    df = clean_column_names(df)

    valid = validate_required_columns(
        df,
        CALENDAR_COLUMNS,
        "calendar"
    )

    if not valid:

        raise ValueError(
            "calendar schema validation failed."
        )

    # --------------------------------------------------------
    # Date
    # --------------------------------------------------------

    df["date"] = pd.to_datetime(
        df["date"],
        errors="coerce"
    )

    invalid_dates = df["date"].isna().sum()

    if invalid_dates > 0:

        print(
            f"⚠ Removing "
            f"{invalid_dates:,} "
            "invalid calendar dates."
        )

        df = df.dropna(
            subset=["date"]
        )

    # --------------------------------------------------------
    # Remove duplicate dates
    # --------------------------------------------------------

    duplicate_dates = (
        df["date"].duplicated().sum()
    )

    if duplicate_dates > 0:

        print(
            f"⚠ Removing "
            f"{duplicate_dates:,} "
            "duplicate calendar dates."
        )

        df = df.drop_duplicates(
            subset=["date"],
            keep="last"
        )

    # --------------------------------------------------------
    # Sort
    # --------------------------------------------------------

    df = (
        df.sort_values("date")
        .reset_index(drop=True)
    )

    print("✓ Calendar sorting completed")

    print_quality_report(
        df,
        "calendar - cleaned"
    )

    return df


# ============================================================
# SAVE CLEAN DATASET
# ============================================================

def save_clean_dataset(df, name):

    # Safety check
    if not isinstance(df, pd.DataFrame):

        raise TypeError(
            f"{name} cleaning function returned "
            f"{type(df).__name__}. "
            "Expected pandas DataFrame."
        )

    output_path = (
        PROCESSED_DIR
        / f"{name}_clean.csv"
    )

    df.to_csv(
        output_path,
        index=False
    )

    print(
        f"\n✓ Saved {name}: "
        f"{len(df):,} rows"
    )

    print(
        f"  Output: {output_path}"
    )


# ============================================================
# MAIN PIPELINE
# ============================================================

def main():

    print("=" * 70)
    print("NORTHBAY FORESIGHT - DATA CLEANING PIPELINE")
    print("=" * 70)

    # --------------------------------------------------------
    # Dataset -> Cleaning function
    # --------------------------------------------------------

    datasets = {
        "sales_daily": clean_sales,
        "sku_master": clean_sku_master,
        "inventory_snapshots": clean_inventory,
        "promotions": clean_promotions,
        "calendar": clean_calendar,
    }

    # --------------------------------------------------------
    # Process each dataset
    # --------------------------------------------------------

    for name, cleaner in datasets.items():

        print("\n" + "=" * 70)
        print(f"DATASET: {name}")
        print("=" * 70)

        input_path = (
            DATA_DIR / f"{name}.csv"
        )

        # ----------------------------------------------------
        # File existence
        # ----------------------------------------------------

        if not input_path.exists():

            print(
                f"⚠ Skipping {name}"
            )

            print(
                f"File not found: {input_path}"
            )

            continue

        # ----------------------------------------------------
        # Read
        # ----------------------------------------------------

        try:

            df = pd.read_csv(
                input_path,
                low_memory=False
            )

        except Exception as error:

            print(
                f"❌ Could not read {name}:"
            )

            print(error)

            continue

        print(
            f"Original rows: "
            f"{len(df):,}"
        )

        print(
            f"Original columns: "
            f"{len(df.columns)}"
        )

        # ----------------------------------------------------
        # Original quality report
        # ----------------------------------------------------

        print_quality_report(
            df,
            f"{name} - original"
        )

        # ----------------------------------------------------
        # Cleaning
        # ----------------------------------------------------

        try:

            cleaned_df = cleaner(df)

        except Exception as error:

            print(
                f"\n❌ Cleaning failed for "
                f"{name}"
            )

            print(
                f"Error: {error}"
            )

            raise

        # ----------------------------------------------------
        # Safety check
        # ----------------------------------------------------

        if not isinstance(
            cleaned_df,
            pd.DataFrame
        ):

            raise TypeError(
                f"{name} cleaner returned "
                f"{type(cleaned_df).__name__} "
                "instead of DataFrame."
            )

        # ----------------------------------------------------
        # Save
        # ----------------------------------------------------

        save_clean_dataset(
            cleaned_df,
            name
        )

    # --------------------------------------------------------
    # Complete
    # --------------------------------------------------------

    print("\n" + "=" * 70)
    print("CLEANING PIPELINE COMPLETE")
    print("=" * 70)

    print(
        f"\nCleaned files are stored in:"
    )

    print(
        f"{PROCESSED_DIR}"
    )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()