from pathlib import Path

import pandas as pd
import numpy as np


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parents[1]

DATA_DIR = BASE_DIR / "data"
PROCESSED_DIR = DATA_DIR / "processed"
REPORT_DIR = BASE_DIR / "reports"

REPORT_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# LOAD DATA
# ============================================================

def load_datasets():

    print("\n" + "=" * 70)
    print("NORTHBAY FORESIGHT - EDA")
    print("=" * 70)

    sales_path = PROCESSED_DIR / "sales_daily_clean.csv"
    sku_path = PROCESSED_DIR / "sku_master_clean.csv"
    inventory_path = PROCESSED_DIR / "inventory_snapshots_clean.csv"
    calendar_path = PROCESSED_DIR / "calendar_clean.csv"

    sales = pd.read_csv(sales_path)
    sku = pd.read_csv(sku_path)
    inventory = pd.read_csv(inventory_path)
    calendar = pd.read_csv(calendar_path)

    print("\nDatasets loaded successfully.")

    print(f"Sales       : {len(sales):,} rows")
    print(f"SKU Master  : {len(sku):,} rows")
    print(f"Inventory   : {len(inventory):,} rows")
    print(f"Calendar    : {len(calendar):,} rows")

    return sales, sku, inventory, calendar


# ============================================================
# SALES EDA
# ============================================================

def analyze_sales(sales):

    print("\n" + "=" * 70)
    print("SALES ANALYSIS")
    print("=" * 70)

    sales = sales.copy()

    sales["date"] = pd.to_datetime(
        sales["date"],
        errors="coerce"
    )

    # --------------------------------------------------------
    # Basic statistics
    # --------------------------------------------------------

    print("\nSales date range:")

    print(
        f"Start : {sales['date'].min()}"
    )

    print(
        f"End   : {sales['date'].max()}"
    )

    # --------------------------------------------------------
    # Total business metrics
    # --------------------------------------------------------

    total_units = sales["units_sold"].sum()

    total_revenue = sales["revenue"].sum()

    total_transactions = sales["transaction_count"].sum()

    print("\nBusiness KPIs")

    print(
        f"Total units sold     : {total_units:,.0f}"
    )

    print(
        f"Total revenue        : {total_revenue:,.2f}"
    )

    print(
        f"Total transactions   : {total_transactions:,.0f}"
    )

    # --------------------------------------------------------
    # Average selling price
    # --------------------------------------------------------

    weighted_price = (
        sales["revenue"].sum()
        / sales["units_sold"].sum()
    )

    print(
        f"Weighted avg price   : {weighted_price:,.2f}"
    )

    # --------------------------------------------------------
    # SKU performance
    # --------------------------------------------------------

    sku_performance = (
        sales
        .groupby("sku_id")
        .agg(
            units_sold=("units_sold", "sum"),
            revenue=("revenue", "sum"),
            transactions=("transaction_count", "sum")
        )
        .sort_values(
            "revenue",
            ascending=False
        )
    )

    print("\nTop 10 SKUs by revenue:")

    print(
        sku_performance.head(10)
    )

    # --------------------------------------------------------
    # Daily sales
    # --------------------------------------------------------

    daily_sales = (
        sales
        .groupby("date")
        .agg(
            units_sold=("units_sold", "sum"),
            revenue=("revenue", "sum")
        )
        .reset_index()
    )

    print("\nDaily sales summary:")

    print(
        daily_sales.describe()
    )

    return {
        "sku_performance": sku_performance,
        "daily_sales": daily_sales
    }


# ============================================================
# INVENTORY EDA
# ============================================================

def analyze_inventory(inventory):

    print("\n" + "=" * 70)
    print("INVENTORY ANALYSIS")
    print("=" * 70)

    inventory = inventory.copy()

    numeric_columns = [
        "stock_on_hand",
        "reorder_point",
        "safety_stock"
    ]

    for column in numeric_columns:

        inventory[column] = pd.to_numeric(
            inventory[column],
            errors="coerce"
        )

    # --------------------------------------------------------
    # Stockout
    # --------------------------------------------------------

    stockout_count = (
        inventory["stock_on_hand"] <= 0
    ).sum()

    print(
        f"\nStockout records : {stockout_count:,}"
    )

    # --------------------------------------------------------
    # Below reorder point
    # --------------------------------------------------------

    reorder_risk = (
        inventory["stock_on_hand"]
        <= inventory["reorder_point"]
    )

    print(
        f"Below reorder point : "
        f"{reorder_risk.sum():,}"
    )

    # --------------------------------------------------------
    # Below safety stock
    # --------------------------------------------------------

    safety_risk = (
        inventory["stock_on_hand"]
        <= inventory["safety_stock"]
    )

    print(
        f"Below safety stock  : "
        f"{safety_risk.sum():,}"
    )

    # --------------------------------------------------------
    # Inventory risk table
    # --------------------------------------------------------

    inventory["stock_status"] = np.select(
        [
            inventory["stock_on_hand"] <= 0,

            inventory["stock_on_hand"]
            <= inventory["safety_stock"],

            inventory["stock_on_hand"]
            <= inventory["reorder_point"]
        ],
        [
            "STOCKOUT",

            "CRITICAL",

            "REORDER"
        ],
        default="HEALTHY"
    )

    status_summary = (
        inventory["stock_status"]
        .value_counts()
    )

    print("\nInventory status:")

    print(
        status_summary
    )

    return inventory


# ============================================================
# SKU ANALYSIS
# ============================================================

def analyze_sku_master(sku):

    print("\n" + "=" * 70)
    print("SKU MASTER ANALYSIS")
    print("=" * 70)

    print(
        f"\nUnique SKUs : "
        f"{sku['sku_id'].nunique():,}"
    )

    print(
        f"Categories  : "
        f"{sku['category'].nunique():,}"
    )

    print(
        f"Subcategories : "
        f"{sku['subcategory'].nunique():,}"
    )

    print("\nCategory distribution:")

    print(
        sku["category"]
        .value_counts()
    )

    print("\nBrand distribution:")

    print(
        sku["brand"]
        .value_counts()
        .head(20)
    )


# ============================================================
# CALENDAR ANALYSIS
# ============================================================

def analyze_calendar(calendar):

    print("\n" + "=" * 70)
    print("CALENDAR ANALYSIS")
    print("=" * 70)

    calendar = calendar.copy()

    calendar["date"] = pd.to_datetime(
        calendar["date"],
        errors="coerce"
    )

    print(
        f"\nCalendar start : "
        f"{calendar['date'].min()}"
    )

    print(
        f"Calendar end   : "
        f"{calendar['date'].max()}"
    )

    print(
        f"Calendar rows  : "
        f"{len(calendar):,}"
    )

    print("\nCalendar columns:")

    print(
        list(calendar.columns)
    )

    return calendar


# ============================================================
# SAVE EDA OUTPUTS
# ============================================================

def save_eda_outputs(
    sales_results,
    inventory,
    output_dir
):

    output_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    sales_results[
        "sku_performance"
    ].to_csv(
        output_dir /
        "sku_performance.csv",
        index=True
    )

    sales_results[
        "daily_sales"
    ].to_csv(
        output_dir /
        "daily_sales_summary.csv",
        index=False
    )

    inventory.to_csv(
        output_dir /
        "inventory_status.csv",
        index=False
    )

    print("\nEDA outputs saved successfully.")


# ============================================================
# MAIN
# ============================================================

def main():

    sales, sku, inventory, calendar = (
        load_datasets()
    )

    sales_results = analyze_sales(
        sales
    )

    inventory_result = analyze_inventory(
        inventory
    )

    analyze_sku_master(
        sku
    )

    analyze_calendar(
        calendar
    )

    save_eda_outputs(
        sales_results,
        inventory_result,
        REPORT_DIR
    )

    print("\n" + "=" * 70)
    print("EDA COMPLETED SUCCESSFULLY")
    print("=" * 70)


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()