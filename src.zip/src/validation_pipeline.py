from pathlib import Path

from validation import validate_file


# ============================================================
# PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

DATA_DIR = PROJECT_ROOT / "data"


# ============================================================
# DATASETS
# ============================================================

DATASETS = [
    "sales_daily",
    "sku_master",
    "inventory_snapshots",
    "calendar",
]


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print("NORTHBAY FORESIGHT")
    print("DATA VALIDATION PIPELINE")
    print("=" * 70)

    results = {}

    for dataset_name in DATASETS:

        file_path = (
            DATA_DIR /
            f"{dataset_name}.csv"
        )

        results[dataset_name] = validate_file(
            file_path,
            dataset_name
        )

    # --------------------------------------------------------
    # FINAL RESULT
    # --------------------------------------------------------

    print("\n" + "=" * 70)
    print("FINAL VALIDATION RESULT")
    print("=" * 70)

    all_passed = True

    for dataset_name, result in results.items():

        if result:

            print(
                f"✓ {dataset_name:<25} PASS"
            )

        else:

            print(
                f"❌ {dataset_name:<25} FAIL"
            )

            all_passed = False

    print("\n" + "=" * 70)

    if all_passed:

        print(
            "✓ ALL DATASETS PASSED VALIDATION"
        )

    else:

        print(
            "⚠ SOME DATASETS NEED ATTENTION"
        )

    print("=" * 70)


if __name__ == "__main__":
    main()