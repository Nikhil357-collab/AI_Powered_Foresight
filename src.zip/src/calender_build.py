from pathlib import Path
import pandas as pd


PROJECT_ROOT = Path("AI_POWERED_FORESIGHT")
PROCESSED_DIR = Path("AI_POWERED_FORESIGHT/data/processed")


def build_calendar():

    sales_path = Path("AI_POWERED_FORESIGHT/data/processed/sales_daily.csv")

    if not sales_path.exists():
        raise FileNotFoundError(
            f"Sales file not found: {sales_path}"
        )

    df = pd.read_csv(sales_path)

    # Find date column
    date_col = "date"

    if date_col not in df.columns:
        raise ValueError(
            f"'{date_col}' column not found in sales file."
        )

    df[date_col] = pd.to_datetime(
        df[date_col],
        errors="coerce"
    )

    df = df.dropna(subset=[date_col])

    min_date = df[date_col].min()
    max_date = df[date_col].max()

    calendar = pd.DataFrame({
        "date": pd.date_range(
            start=min_date,
            end=max_date,
            freq="D"
        )
    })

    # Time features
    calendar["year"] = calendar["date"].dt.year
    calendar["month"] = calendar["date"].dt.month
    calendar["month_name"] = calendar["date"].dt.month_name()
    calendar["week"] = calendar["date"].dt.isocalendar().week.astype(int)
    calendar["day"] = calendar["date"].dt.day
    calendar["day_of_week"] = calendar["date"].dt.dayofweek
    calendar["day_name"] = calendar["date"].dt.day_name()
    calendar["quarter"] = calendar["date"].dt.quarter

    calendar["is_weekend"] = (
        calendar["day_of_week"] >= 5
    ).astype(int)

    # Basic season
    calendar["season"] = calendar["month"].map({
        12: "Winter",
        1: "Winter",
        2: "Winter",
        3: "Spring",
        4: "Spring",
        5: "Spring",
        6: "Summer",
        7: "Summer",
        8: "Summer",
        9: "Autumn",
        10: "Autumn",
        11: "Autumn"
    })

    calendar["is_holiday"] = 0
    calendar["promo_event"] = "None"

    PROCESSED_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    output_path = PROCESSED_DIR / "calendar.csv"

    calendar.to_csv(
        output_path,
        index=False
    )

    print(
        f"Calendar created successfully: {output_path}"
    )

    print(
        f"Date range: {min_date.date()} → {max_date.date()}"
    )

    print(
        f"Rows: {len(calendar):,}"
    )


if __name__ == "__main__":
    build_calendar()