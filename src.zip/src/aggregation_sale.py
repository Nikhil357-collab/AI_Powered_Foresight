from pathlib import Path
import pandas as pd


PROJECT_ROOT = Path("AI_POWERED_FORESIGHT")
PROCESSED_DIR = Path("AI_POWERED_FORESIGHT/data/processed")


def create_sales_daily():

    input_file = Path("AI_POWERED_FORESIGHT/data/sales_transactions.csv")

    if not input_file.exists():

        # Temporary support if you kept original name
        input_file = "AI_POWERED_FORESIGHT/data/sales_daily.csv"

    if not input_file.exists():
        raise FileNotFoundError(
            "Sales transaction CSV not found."
        )

    df = pd.read_csv(input_file)

    required_columns = [
        "date",
        "store_id",
        "sku_id",
        "quantity",
        "unit_price"
    ]

    missing = [
        col for col in required_columns
        if col not in df.columns
    ]

    if missing:
        raise ValueError(
            f"Missing columns: {missing}"
        )

    # -------------------------
    # DATE
    # -------------------------

    df["date"] = pd.to_datetime(
        df["date"],
        errors="coerce"
    )

    df = df.dropna(
        subset=["date"]
    )

    # -------------------------
    # NUMERIC COLUMNS
    # -------------------------

    numeric_columns = [
        "quantity",
        "unit_price",
        "total_value",
        "discount_pct"
    ]

    for col in numeric_columns:

        if col in df.columns:

            df[col] = pd.to_numeric(
                df[col],
                errors="coerce"
            )

    # -------------------------
    # REMOVE INVALID SALES
    # -------------------------

    df = df[
        df["quantity"] >= 0
    ]

    df = df[
        df["unit_price"] >= 0
    ]

    # -------------------------
    # PROMOTION FLAG
    # -------------------------

    if "promo_id" in df.columns:

        df["promo_flag"] = (
            df["promo_id"]
            .notna()
            &
            (
                df["promo_id"]
                .astype(str)
                .str.strip()
                .ne("")
            )
        ).astype(int)

    else:

        df["promo_flag"] = 0

    # -------------------------
    # DAILY SKU-STORE GRAIN
    # -------------------------

    daily = (
        df
        .groupby(
            [
                "date",
                "store_id",
                "sku_id"
            ],
            as_index=False
        )
        .agg(
            units_sold=(
                "quantity",
                "sum"
            ),
            revenue=(
                "total_value",
                "sum"
            ),
            avg_unit_price=(
                "unit_price",
                "mean"
            ),
            transaction_count=(
                "receipt_id",
                "nunique"
            ),
            promo_flag=(
                "promo_flag",
                "max"
            )
        )
    )

    # -------------------------
    # SAVE
    # -------------------------

    PROCESSED_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    output_file = (
        PROCESSED_DIR /
        "sales_daily.csv"
    )

    daily.to_csv(
        output_file,
        index=False
    )

    print(
        f"Created: {output_file}"
    )

    print(
        f"Rows: {len(daily):,}"
    )


if __name__ == "__main__":
    create_sales_daily()