from pathlib import Path

# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parents[1]

DATA_DIR = PROJECT_ROOT / "data"
PROCESSED_DIR = PROJECT_ROOT/ "data" / "processed"

REPORTS_DIR = PROJECT_ROOT / "reports"
MODELS_DIR = PROJECT_ROOT / "models"
SRC_DIR = PROJECT_ROOT / "src"

# ============================================================
# RAW FILES
# ============================================================

SALES_FILE = DATA_DIR / "sales_daily.csv"
SKU_FILE = DATA_DIR / "sku_master.csv"
INVENTORY_FILE = DATA_DIR / "inventory_snapshots.csv"
CALENDAR_FILE = DATA_DIR / "calendar.csv"
PROMOTIONS_FILE = DATA_DIR / "promotions.csv"

# ============================================================
# PROJECT SETTINGS
# ============================================================

RANDOM_STATE = 42

FORECAST_HORIZON_DAYS = 28

TARGET_COLUMN = "units_sold"

GROUP_COLUMNS = [
    "store_id",
    "sku_id"
]