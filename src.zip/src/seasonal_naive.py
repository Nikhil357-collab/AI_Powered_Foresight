from pathlib import Path

import numpy as np
import pandas as pd


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parents[1]

DATA_DIR = BASE_DIR / "data"
PROCESSED_DIR = DATA_DIR / "processed"

PROCESSED_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# CONFIGURATION
# ============================================================

DATE_COLUMN = "date"
SKU_COLUMN = "sku_id"
TARGET_COLUMN = "units_sold"

SEASONAL_PERIOD = 7

TEST_DAYS = 30


# ============================================================
# LOAD DATA
# ============================================================

def load_sales_data():

    input_path = (
        PROCESSED_DIR /
        "sales_daily_clean.csv"
    )

    if not input_path.exists():

        raise FileNotFoundError(
            f"\nSales file not found:\n{input_path}\n\n"
            "Make sure sales_daily_clean.csv exists "
            "inside data/processed/"
        )

    print("\nLoading cleaned sales data...")

    df = pd.read_csv(
        input_path
    )

    required_columns = [
        DATE_COLUMN,
        SKU_COLUMN,
        TARGET_COLUMN
    ]

    missing_columns = [
        col
        for col in required_columns
        if col not in df.columns
    ]

    if missing_columns:

        raise ValueError(
            "\nMissing required columns: "
            f"{missing_columns}"
        )

    df[DATE_COLUMN] = pd.to_datetime(
        df[DATE_COLUMN],
        errors="coerce"
    )

    df[TARGET_COLUMN] = pd.to_numeric(
        df[TARGET_COLUMN],
        errors="coerce"
    )

    df = df.dropna(
        subset=[
            DATE_COLUMN,
            SKU_COLUMN,
            TARGET_COLUMN
        ]
    )
    df["baseline_forecast"] = df.groupby(SKU_COLUMN)[TARGET_COLUMN].shift(SEASONAL_PERIOD)
    return df
#########################
##############========
# ============================================================
# CREATE SKU-DAY DATASET
# ============================================================

def create_sku_daily_dataset(df):

    print("\nCreating SKU-day demand dataset...")

    sku_daily = (
        df.groupby(
            [
                DATE_COLUMN,
                SKU_COLUMN
            ],
            as_index=False
        )[TARGET_COLUMN]
        .sum()
    )

    sku_daily = sku_daily.sort_values(
        [
            SKU_COLUMN,
            DATE_COLUMN
        ]
    ).reset_index(
        drop=True
    )

    print(
        f"SKU-day rows: "
        f"{len(sku_daily):,}"
    )

    print(
        f"Unique SKUs: "
        f"{sku_daily[SKU_COLUMN].nunique():,}"
    )

    print(
        f"Date range: "
        f"{sku_daily[DATE_COLUMN].min().date()} "
        f"to "
        f"{sku_daily[DATE_COLUMN].max().date()}"
    )

    return sku_daily


# ============================================================
# CREATE SEASONAL-NAIVE FORECAST
# ============================================================

def create_seasonal_naive_forecast(
    df
):

    print(
        "\nCreating seasonal-naive forecast..."
    )

    df = df.copy()

    # Previous week's demand
    df["baseline_forecast"] = (
        df.groupby(SKU_COLUMN)[TARGET_COLUMN]
        .shift(SEASONAL_PERIOD)
    )

    return df


# ============================================================
# TIME-BASED TEST SPLIT
# ============================================================

def create_test_period(
    df
):

    print(
        "\nCreating time-based test period..."
    )

    max_date = df[DATE_COLUMN].max()

    test_start = (
        max_date -
        pd.Timedelta(
            days=TEST_DAYS - 1
        )
    )

    df["is_test"] = (
        df[DATE_COLUMN] >= test_start
    )

    print(
        f"Test period: "
        f"{test_start.date()} "
        f"to "
        f"{max_date.date()}"
    )

    print(
        f"Test rows: "
        f"{df['is_test'].sum():,}"
    )

    return df


# ============================================================
# WAPE
# ============================================================

def calculate_wape(
    actual,
    forecast
):

    actual = np.asarray(
        actual,
        dtype=float
    )

    forecast = np.asarray(
        forecast,
        dtype=float
    )

    absolute_error = np.abs(
        actual - forecast
    )

    total_actual = np.sum(
        np.abs(actual)
    )

    if total_actual == 0:

        return np.nan

    wape = (
        np.sum(absolute_error)
        /
        total_actual
    )

    return wape


# ============================================================
# MAPE
# ============================================================

def calculate_mape(
    actual,
    forecast
):

    actual = np.asarray(
        actual,
        dtype=float
    )

    forecast = np.asarray(
        forecast,
        dtype=float
    )

    valid = actual != 0

    if valid.sum() == 0:

        return np.nan

    percentage_error = (
        np.abs(
            actual[valid] -
            forecast[valid]
        )
        /
        np.abs(actual[valid])
    )

    return np.mean(
        percentage_error
    )


# ============================================================
# BIAS
# ============================================================

def calculate_bias(
    actual,
    forecast
):

    actual = np.asarray(
        actual,
        dtype=float
    )

    forecast = np.asarray(
        forecast,
        dtype=float
    )

    return np.mean(
        forecast - actual
    )


# ============================================================
# EVALUATE BASELINE
# ============================================================

def evaluate_baseline(
    df
):

    print(
        "\nEvaluating seasonal-naive baseline..."
    )

    test_data = df[
        df["is_test"]
    ].copy()

    # Rows without previous-week
    # demand cannot be evaluated.
    test_data = test_data.dropna(
        subset=[
            "baseline_forecast"
        ]
    )

    if test_data.empty:

        raise ValueError(
            "\nNo valid baseline predictions "
            "available for the test period."
        )

    actual = test_data[
        TARGET_COLUMN
    ]

    forecast = test_data[
        "baseline_forecast"
    ]

    wape = calculate_wape(
        actual,
        forecast
    )

    mape = calculate_mape(
        actual,
        forecast
    )

    bias = calculate_bias(
        actual,
        forecast
    )

    print("\n" + "=" * 70)
    print("SEASONAL-NAIVE BASELINE RESULTS")
    print("=" * 70)

    print(
        f"WAPE : {wape:.4f} "
        f"({wape * 100:.2f}%)"
    )

    print(
        f"MAPE : {mape:.4f} "
        f"({mape * 100:.2f}%)"
    )

    print(
        f"Bias : {bias:.4f}"
    )

    print(
        f"Evaluation rows: "
        f"{len(test_data):,}"
    )

    return test_data, wape, mape, bias


# ============================================================
# SAVE RESULTS
# ============================================================

def save_results(
    all_data,
    test_data,
    wape,
    mape,
    bias
):

    predictions_path = (
        PROCESSED_DIR /
        "seasonal_naive_predictions.csv"
    )

    metrics_path = (
        PROCESSED_DIR /
        "seasonal_naive_metrics.csv"
    )

    all_data.to_csv(
        predictions_path,
        index=False
    )

    metrics = pd.DataFrame(
        {
            "model": [
                "Seasonal Naive"
            ],
            "seasonal_period_days": [
                SEASONAL_PERIOD
            ],
            "test_days": [
                TEST_DAYS
            ],
            "WAPE": [
                wape
            ],
            "MAPE": [
                mape
            ],
            "Bias": [
                bias
            ]
        }
    )

    metrics.to_csv(
        metrics_path,
        index=False
    )

    print(
        "\n✓ Baseline predictions saved:"
    )

    print(
        predictions_path
    )

    print(
        "\n✓ Baseline metrics saved:"
    )

    print(
        metrics_path
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 70)
    print(
        "NORTHBAY FORESIGHT - "
        "SEASONAL NAIVE BASELINE"
    )
    print("=" * 70)

    # --------------------------------------------------------
    # STEP 1: LOAD
    # --------------------------------------------------------

    sales = load_sales_data()

    print(
        f"\nOriginal cleaned rows: "
        f"{len(sales):,}"
    )

    # --------------------------------------------------------
    # STEP 2: SKU-DAY AGGREGATION
    # --------------------------------------------------------

    sku_daily = (
        create_sku_daily_dataset(
            sales
        )
    )

    # --------------------------------------------------------
    # STEP 3: BASELINE FORECAST
    # --------------------------------------------------------

    baseline = (
        create_seasonal_naive_forecast(
            sku_daily
        )
    )

    # --------------------------------------------------------
    # STEP 4: TEST PERIOD
    # --------------------------------------------------------

    baseline = (
        create_test_period(
            baseline
        )
    )

    # --------------------------------------------------------
    # STEP 5: EVALUATION
    # --------------------------------------------------------

    (
        test_data,
        wape,
        mape,
        bias
    ) = evaluate_baseline(
        baseline
    )

    # --------------------------------------------------------
    # STEP 6: SAVE
    # --------------------------------------------------------

    save_results(
        baseline,
        test_data,
        wape,
        mape,
        bias
    )

    # --------------------------------------------------------
    # COMPLETE
    # --------------------------------------------------------

    print(
        "\n" + "=" * 70
    )

    print(
        "DAY 10 BASELINE COMPLETE"
    )

    print(
        "=" * 70
    )


# ============================================================
# RUN
# ============================================================

if __name__ == "__main__":
    main()