from pathlib import Path

import pandas as pd

from sales_cleaner import (
    clean_sales,
    clean_sku_master,
    clean_inventory,
    clean_promotions
)

from validation import (
    validate_dataset,
    quality_report
)


# ============================================================
# PROJECT PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parents[1]

DATA_DIR = BASE_DIR / "data"

PROCESSED_DIR = DATA_DIR / "processed"

PROCESSED_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# DATASET CONFIGURATION
# ============================================================

DATASETS = {

    "sales_daily": {
        "cleaner": clean_sales
    },

    "sku_master": {
        "cleaner": clean_sku_master
    },

    "inventory_snapshots": {
        "cleaner": clean_inventory
    },

    "promotions": {
        "cleaner": clean_promotions
    }
}


# ============================================================
# CALENDAR
# ============================================================

def clean_calendar(df):

    df = df.copy()

    print("\nCleaning calendar...")

    # Standardize columns

    df.columns = (
        df.columns
        .astype(str)
        .str.strip()
        .str.lower()
        .str.replace(" ", "_", regex=False)
    )

    # Convert date

    df["date"] = pd.to_datetime(
        df["date"],
        errors="coerce"
    )

    # Remove invalid dates

    df = df.dropna(
        subset=["date"]
    )

    # Remove duplicates

    df = df.drop_duplicates(
        subset=["date"]
    )

    # Sort

    df = df.sort_values(
        "date"
    ).reset_index(drop=True)

    return df


# ============================================================
# LOAD DATASET
# ============================================================

def load_dataset(name):

    path = DATA_DIR / f"{name}.csv"

    if not path.exists():

        print(
            f"\n⚠ File not found: {path}"
        )

        return None

    print("\n" + "=" * 70)

    print(
        f"DATASET: {name}"
    )

    print("=" * 70)

    print(
        f"File: {path}"
    )

    df = pd.read_csv(path)

    print(
        f"Original rows: "
        f"{len(df):,}"
    )

    print(
        f"Original columns: "
        f"{len(df.columns)}"
    )

    return df


# ============================================================
# PROCESS ONE DATASET
# ============================================================

def process_dataset(name, cleaner):

    df = load_dataset(name)

    if df is None:
        return False

    # --------------------------------------------------------
    # CLEAN
    # --------------------------------------------------------

    print(
        f"\nCleaning {name}..."
    )

    cleaned_df = cleaner(df)

    # --------------------------------------------------------
    # SAFETY CHECK
    # --------------------------------------------------------

    if not isinstance(
        cleaned_df,
        pd.DataFrame
    ):

        raise TypeError(
            f"{name} cleaner returned "
            f"{type(cleaned_df).__name__} "
            f"instead of pandas DataFrame."
        )

    # --------------------------------------------------------
    # VALIDATE
    # --------------------------------------------------------

    print(
        f"\nValidating {name}..."
    )

    validation_result = validate_dataset(
        cleaned_df,
        name
    )

    if not validation_result:

        raise ValueError(
            f"{name} failed schema validation."
        )

    # --------------------------------------------------------
    # QUALITY REPORT
    # --------------------------------------------------------

    quality_report(
        cleaned_df,
        name
    )

    # --------------------------------------------------------
    # SAVE
    # --------------------------------------------------------

    output_path = (
        PROCESSED_DIR /
        f"{name}_clean.csv"
    )

    cleaned_df.to_csv(
        output_path,
        index=False
    )

    print(
        f"\n✓ CLEANED DATA SAVED"
    )

    print(
        output_path
    )

    print(
        f"Rows after cleaning: "
        f"{len(cleaned_df):,}"
    )

    return True


# ============================================================
# MAIN
# ============================================================

def main():

    print("\n" + "=" * 70)

    print(
        "NORTHBAY FORESIGHT"
    )

    print(
        "DATA CLEANING & VALIDATION PIPELINE"
    )

    print("=" * 70)

    # --------------------------------------------------------
    # PROCESS MAIN DATASETS
    # --------------------------------------------------------

    for name, config in DATASETS.items():

        process_dataset(
            name,
            config["cleaner"]
        )

    # --------------------------------------------------------
    # PROCESS CALENDAR
    # --------------------------------------------------------

    calendar_df = load_dataset(
        "calendar"
    )

    if calendar_df is not None:

        print(
            "\nCleaning calendar..."
        )

        calendar_clean = clean_calendar(
            calendar_df
        )

        if not isinstance(
            calendar_clean,
            pd.DataFrame
        ):

            raise TypeError(
                "Calendar cleaner did not "
                "return a DataFrame."
            )

        # Validate

        validation_result = validate_dataset(
            calendar_clean,
            "calendar"
        )

        if not validation_result:

            raise ValueError(
                "Calendar failed validation."
            )

        # Quality report

        quality_report(
            calendar_clean,
            "calendar"
        )

        # Save

        calendar_output = (
            PROCESSED_DIR /
            "calendar_clean.csv"
        )

        calendar_clean.to_csv(
            calendar_output,
            index=False
        )

        print(
            f"\n✓ CLEANED CALENDAR SAVED"
        )

        print(
            calendar_output
        )

    # --------------------------------------------------------
    # COMPLETE
    # --------------------------------------------------------

    print("\n" + "=" * 70)

    print(
        "PIPELINE COMPLETED SUCCESSFULLY"
    )

    print("=" * 70)

    print(
        "\nProcessed files are available at:"
    )

    print(
        PROCESSED_DIR
    )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()